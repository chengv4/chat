import{w as e,u as o}from"./vendor-DJ8gqV4u.js";const r=({from:r,replacement:s,scope:m,version:t,ref:a,type:p="API"},i)=>{e((()=>o(i)),(e=>{}),{immediate:!0})};export{r as u};
