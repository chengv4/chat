class r extends Error{constructor(r){super(r),this.name="ElementPlusError"}}function t(t,n){throw new r(`[${t}] ${n}`)}function n(r,t){}export{n as d,t};
